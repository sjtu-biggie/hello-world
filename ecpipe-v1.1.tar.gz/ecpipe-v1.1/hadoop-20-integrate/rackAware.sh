#!/bin/bash
echo "/default-rack"
