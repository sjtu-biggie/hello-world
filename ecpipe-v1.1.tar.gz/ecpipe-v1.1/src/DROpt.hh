#ifndef __DROPT_HH__
#define __DROPT_HH__

#define CONV_OPT 1
#define PIPE_MUL_OPT 11 // 11
#define PPR_MUL_OPT 1 

#endif
