# ECPipe

ECPipe is a system reducing time complexity of
degraded read operations to O(1).

## System Design

ECPipe is **NOT** designed to be a part of some specific file system.  Instead,
ECPipe is running as a separated system attached to file system.  

### Inter-host Communication
Using [Redis](http://redis.io/).

```

```

Commands format:

  * **Issue dr request** (Client to Coordinator)

| requestor IP | lost block name length | lost block name |
|--------------|------------------------|-----------------|
|   4 Bytes    |         4 Bytes        |     ? Bytes     |

  * **Distribute dr request** (Coordinator to Helper)
  * **Send back data** (Helper to Client)

**A little explanation**: I spent quit a lot time hesitating what to use for
the inter-host communication.  I intended to use raw socket programing or
ZeroMQ to do the work.  

However...  I realized that it would be a total mass trying to manage the
serialization of degraded read requests...  Think about two requests going
through same hop and the two nodes get commands in different orders.  This is
also the same reason that drives me to use a dedicated degraded read
coordinator. 

Well, we can use ZeroMQ to handle data flow.  But not sure whether we can use
it in the first realize.

### Intra-host Communication
Using **Conditional Variable** to coordinate different threads.

```

  recv from     ______________    send to
   Network      |            |    network
--------------->|   Memory   |--------------->
                |            |
                --------------
                 read ^
                 from |
                 disk |
```

## Source code structure
  * src/
  * src/java 
    Source codes implementing the input stream of ECPipe
